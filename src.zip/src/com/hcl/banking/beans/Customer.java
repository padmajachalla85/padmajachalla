package com.hcl.banking.beans;

import java.util.*;


public class Customer 
{
	private String accNo;
	private String password;
	private double balance;
	private List<Address> address;
	
	
	
	public List<Address> getAddress() {
		return address;
	}
	public void setAddress(List<Address> address) {
		this.address = address;
	}
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Customer [accNo=" + accNo + ", password=" + password + ", balance=" + balance + ", address=" + address
				+ "]";
	}
	
	
	
	
	}
	
	
	
	
	


