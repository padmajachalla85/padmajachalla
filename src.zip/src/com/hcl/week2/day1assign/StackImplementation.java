package com.hcl.week2.day1assign;

import java.util.*;

public class StackImplementation 
{
	public static void main(String args[])
	{
	Stack<String> stack = new Stack<>();
	stack.push("abc");
	stack.push("def");
	stack.push("ghi");
	stack.push("jkl");
	
	System.out.println(stack);
	
	Iterator<String> itr = stack.iterator();
	while(itr.hasNext())
	{
		System.out.println(itr.next());
	}
	 
	
	}

}

