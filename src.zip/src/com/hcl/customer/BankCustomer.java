package com.hcl.customer;
import java.util.Scanner;
import com.hcl.account.BankAccount;

public class BankCustomer
{
	public static void main(String args[])
	{
		
		System.out.println("Welcome to "+BankAccount.bankName+" bank");
		System.out.println("Enter the number of customers you want to enter:");
		Scanner in = new Scanner(System.in);
		int i = in.nextInt();
		BankAccount BC[] = new BankAccount[i];
		for(int a=0;a< BC.length;a++)
		{
		System.out.println("Enter the Account number of "+(a+1)+"Customer");
		String s=in.next();
		System.out.println("Enter the name of "+(a+1)+"Customer");
		String s1=in.next();
		System.out.println("Enter the deposit "+(a+1)+"Customer");
		Long l1=in.nextLong();		
		BC[a] = new BankAccount(s,s1,l1);
		}
		
		for(int j=0;j<BC.length;j++)
		{
			BC[j].displayInfo();
		}
		
		
		
		
	}

}
