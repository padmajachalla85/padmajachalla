package com.hcl.day3assign;

public class ThreeDimensionShape
{
	double width,height,depth;
	
	ThreeDimensionShape(double w,double h,double d)
	{
	this.width=w;
	this.height=h;
	this.depth=d;
	}
	
	ThreeDimensionShape(double l)
	{
		this.width=l;
		this.height=l;
		this.depth=l;
	}

	ThreeDimensionShape()
	{
		this.width=0;
		this.height=0;
		this.depth=0;
	}
	
	double volume()
	{
		return width*height*depth;
	}
	

}
