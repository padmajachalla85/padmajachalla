package com.hcl.week2.day1assign;

import java.util.*;

public class ArrayListImplementation
{
	public static void main(String args[])
	{
		Scanner in = new Scanner(System.in);
		List <Integer> l1 = new ArrayList<Integer>();
		System.out.println("Enter the number of elemets");
		int i = in.nextInt();
		
		for(int j=0;j<i;j++)
		{
			l1.add(in.nextInt());
			
		}
		System.out.println("The size of the ArrayList is " +l1.size());
		int min = l1.get(0);
		int max = l1.get(0);
		
		for(int k:l1)
		{
			if(k<min)
			{
				min = k;
			}
		}
		
		for(int l:l1)
		{
			if(l>max)
			{
				max = l;
			}
		}
		
		
		System.out.println("The minimum number in the list is " +min);

		System.out.println("The maximum number in the list is " +max);
		
		if(l1.isEmpty())
		System.out.println("The list is Empty");
		else
		System.out.println("The list is NOT Empty");
			
		System.out.println("Enter the index of element to be removed");
		int remInd = in.nextInt();
		l1.remove(remInd);
		System.out.println(l1);
		
		System.out.println("Enter the element to be removed");
		int remNum = in.nextInt();
		Iterator<Integer> itr = l1.iterator();
		while(itr.hasNext())
		{
			int data = (Integer)itr.next();
			if(data == remNum)
			{
				//System.out.println("Entered");
				itr.remove();
			}
		}
		
		for(int al : l1)
		{
			
	
		System.out.println(al);
		
		}
	in.close();	
		
		
		
	}
	

}

