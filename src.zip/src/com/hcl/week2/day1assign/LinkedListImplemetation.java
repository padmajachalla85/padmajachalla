package com.hcl.week2.day1assign;
import java.util.*;
public class LinkedListImplemetation
{
	public static void main(String args[])
	{
		LinkedList<Integer> list = new LinkedList<>();
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the elements");
		while(in.hasNextInt())
		{
			list.add(in.nextInt());
		}
		in.close();
		
		Collections.sort(list);
		System.out.println("Ascending order" +list);
		Collections.sort(list,Collections.reverseOrder());
		System.out.println("Descending order" +list);
		
	}

	
}
