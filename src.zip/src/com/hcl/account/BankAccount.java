package com.hcl.account;

public class BankAccount
{
	public static String bankName="DBS";
	public String accNo;
	public String customerName;
	public long balance;
	
	/*public BankAccount()
	{
		
	}*/
	
	public BankAccount(String accNo,String customerName,long balance)
	{
		this.accNo=accNo;
		this.customerName=customerName;
		this.balance=balance;
		
	}
	
	public void displayInfo()
	{
		System.out.println("The Customer details are Accno="+accNo+" customer name="+customerName+" and"
				+ "Available Balance is="+balance+"");
	}
	
	

}
