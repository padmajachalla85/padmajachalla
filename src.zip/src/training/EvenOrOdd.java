package training;
import java.util.Scanner;

public class EvenOrOdd {
	
	public static void main(String args[])
	{
		
		System.out.print("Choose Method for finding whether the number is Even or Odd\n");
		System.out.println("Enter 1 for if else method");
		System.out.println("Enter 2 for Ternary Operator Method");
		Scanner in = new Scanner(System.in);
		int option = in.nextInt();
		
		if(option==1)
		{
			System.out.println("Enter the number");
			int num = in.nextInt();
			String s=checkEvenOrOdd(num);
			System.out.println("Number is "+s);			
		}
		
		else if(option == 2)
		{
			System.out.println("Enter the number");
			int num = in.nextInt();
			String s1=checkTernaryMethod(num);
			System.out.println("Number is "+s1);
		}
		else
		{
			System.out.println("Invalid Option");
		}
		
	}
	
	public static String checkEvenOrOdd(int a)
	{
		if(a%2 == 0)
			return "Even";
		else 
			return "Odd";
	}
	
	public static String checkTernaryMethod(int x)
	{
		return (x%2==0)? "Even" : "Odd";
		//String a=(x%2==0)? "Even" : "Odd";
		//return a;
		
	}
	

}
