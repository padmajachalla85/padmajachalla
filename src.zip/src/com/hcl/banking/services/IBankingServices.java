package com.hcl.banking.services;

import java.util.*;

import com.hcl.banking.beans.Address;
import com.hcl.banking.beans.Customer;

public interface IBankingServices
{
	public List<Customer> addCustomer(List<Customer> list,Customer c,String acctNO,String pass,double bal,List<Address> addList);
	public List<Address> addAddress(List<Address> addList,int num,Customer c);
	public Customer deposit(Customer c,double amount);
	public Customer withDraw(Customer c,double amount);
	public Customer transfer(Customer c,double amount);
	public int generateOTP();
}
