package com.hcl.banking.services;
import java.util.*;

import com.hcl.banking.beans.Address;
import com.hcl.banking.beans.Customer;

public class BankingServicesImpl implements IBankingServices
{
	
	
	
	@Override
	public Customer deposit(Customer c,double amount)
	{
		double bal = c.getBalance()+amount;
		c.setBalance(bal);
		return c;
		
	}

	@Override
	public Customer withDraw(Customer c,double amount)
	{
		if(amount<c.getBalance())
		{
			double balance = c.getBalance()-amount;
			c.setBalance(balance);
		}
		else
		{
			System.out.println("No enough funds");
		}
		return c;
	}
	
	
	@Override
	public Customer transfer(Customer c,double amount)
	{
		if(amount<c.getBalance())
		{
			double trabalance = c.getBalance()-amount;
			c.setBalance(trabalance);
		}
		else
		{
			System.out.println("No enough funds");
		}
		return c;
	}
	
	
	
	
	@Override
	public int generateOTP()
	{
		return (int)(Math.random()*10000); 
	}

	@Override
	public List<Customer> addCustomer(List<Customer> list, Customer c, String acctNO, String pass, double bal, List<Address> addList) {
		c.setAccNo(acctNO);
		c.setPassword(pass);
		c.setBalance(bal);
		c.setAddress(addList);
		list.add(c);
		return list;
	}

	@Override
	public List<Address> addAddress(List<Address> addList, int num, Customer c)
	{	
		Scanner scr = new Scanner(System.in);
		for(int i=0;i<num;i++)
		{
			System.out.println("Enter House no:");
			int houseNo =scr.nextInt();
			System.out.println("Enter Street Name");
			String streetName =scr.next();
			System.out.println("Enter the city");
			String city =scr.next();
			System.out.println("Enter pin code");
			int pincode = scr.nextInt();
			
			Address adr = new Address();
			adr.setHouseNo(houseNo);
			adr.setStreetName(streetName);
			adr.setCityName(city);
			adr.setPinCode(pincode);
			addList.add(adr);
			
		}
		return addList;
	}
	

	
	
	
}
