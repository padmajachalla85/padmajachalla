package com.hcl.day4assign;

class Account
{
	String customerName;
	int accountNo;
	
	Account(String name,int num)
	{
		this.customerName = name;
		this.accountNo = num;
	}
	
	void display()
	{
		System.out.println("Customer name="+customerName+" and Account no="+accountNo);
	}
	
}

class CurrentAccount extends Account
{
	int currentBalance;
	CurrentAccount(String name,int num,int balance)
	{
		super(name,num);
		this.currentBalance = balance;
	}
	
	void display()
	{
		super.display();
		System.out.println("Current balance is "+currentBalance);
	}
	
}

class AccountDetails extends CurrentAccount
{
	int depositAmount;
	int withdrawalAmount;
	AccountDetails(String name,int anum,int balance,int dAmt, int wAmt)
	{
		super(name,anum,balance);
		this.depositAmount=dAmt;
		this.withdrawalAmount=wAmt;
	}
	
	void display()
	{
		super.display();
		System.out.println("Deposit Amount is "+depositAmount);
		System.out.println("Withdrawal Amount is "+withdrawalAmount);
	}
}



public class AccountDemo 
{
	public static void main(String args[])
	{
		AccountDetails account = new AccountDetails("padmaja",1234,10000,5000,4000);
		account.display();
	}
}
