package com.hcl.day4assign;

public interface ICommon {
	
	public String markAttendance();
	public String dailyTask();
	public String displayDetails();
	

}
