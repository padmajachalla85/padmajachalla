package training;
import java.util.Scanner;
public class Day2Assi
{
	public static void main(String args[])
	{
		while(true)
		{
			
			System.out.println("Enter the Assignment number(1-4) and 5 for exiting");
			
			Scanner in = new Scanner(System.in);
			int i = in.nextInt();
			
			switch(i)
			{
				case 1 :
					printRev();
					break;
				case 2 :
					printPattern();
					break;
				case 3 :
					stringEqual();
					break;
				case 4:
					sumOfEvenOddIndexes();
					break;
				case 5:
					System.out.println("Exiting..");
					System.exit(1);
					break;
				default:
					System.out.println("Invalid Input");
			}
	}
	
}

	public static void printRev()
	{
		int i=10;
		while(i>0)
		{
			System.out.println(i);
			i--;
		}
		
		
	}
	public static void printPattern()
	{
		System.out.println("Enter the number of rows");
		Scanner in=new Scanner(System.in);
		int row=in.nextInt();
		
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print("*");
			}
			System.out.println();
			
		}
		
		
	}
	
	public static void stringEqual()
	{
		System.out.println("Comparing Strings");
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the first string1");
		String s1=in.nextLine();
		String s2=in.nextLine();
		if(s1.equals(s2))
			System.out.println("Both the strings are EQUAL");
		else
			System.out.println("Both the strings are NOT EQUAL");
		
		
		
	}
	
	public static void sumOfEvenOddIndexes()
	{
		int evenSum=0,oddSum=0;
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the size of Array");
		int length=in.nextInt();
		int[] arr=new int[length];
		System.out.println("Enter the elements of Array");
		for(int i=0;i<length;i++)
		   arr[i]=in.nextInt();
	
		for(int j=0;j<arr.length;j++)
		{
			if(j%2==0)
			evenSum=evenSum+arr[j];
			else
			oddSum=oddSum+arr[j];
		}
		
		System.out.println("Sum of Even Index nos is " +evenSum);
		System.out.println("Sum of Odd Index nos is " +oddSum);
		
		
		
	}
	
}
