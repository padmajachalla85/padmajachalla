package com.hcl.day3assign;

public class SuperClassDemo
{
	public static void main(String args[])
	{
		Vehicle vehicle=new Vehicle();
		Vehicle scooter=new Scooter();
		Vehicle car=new Car();
		
	vehicle.noOfWheels();
	scooter.noOfWheels();
	car.noOfWheels();
	}
	
}

class Vehicle
{
	
	public void noOfWheels()
	{
		System.out.println("No of wheels undefined");
		
	}
}

class Scooter extends Vehicle
{
	
	public void noOfWheels()
	{
		System.out.println("No of wheels are 2");
	}
	
}

class Car extends Vehicle
{
	public void noOfWheels()
	{
		System.out.println("No of wheels are 4");	
		}
	
}


