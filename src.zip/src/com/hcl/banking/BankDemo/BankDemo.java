package com.hcl.banking.BankDemo;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;

import com.hcl.banking.beans.Address;
import com.hcl.banking.beans.Customer;
import com.hcl.banking.services.BankingServicesImpl;

public class BankDemo extends BankingServicesImpl
{	
	public static void main(String args[])
	{
		List <Customer> custArr = new ArrayList<Customer>();
		
		try
		{
		//	FileReader fr = new FileReader("C:\\Users\\padmaja.challa\\OneDrive - HCL Technologies Ltd\\Desktop\\important.txt");
		FileReader fr = new FileReader("abc.txt");
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		//boolean doContinue = true;
		while(true)
		{
		System.out.println("Enter 1 to add customers\nEnter 2 Dispaly the customers\nEnter 3 Login\nEnter 4 Logout");
		Scanner in = new Scanner(System.in);
		if(in.hasNextInt())
		{
		int option1 = in.nextInt();
		BankingServicesImpl serobj = new BankingServicesImpl();

		switch(option1)
		{
		case 1:
			//Code to add customers
			System.out.println("Enter the Account number");
			String acctno = in.next();
			System.out.println("Enter the Password");
			String passwd = in.next();
			System.out.println("Enter the Balance");
			//boolean balVer = true;
			while(in.hasNext())
			{
				
			if(in.hasNextDouble())
			{
				double balance = in.nextDouble();
				System.out.println("Enter the number of address you want to add");
				if(in.hasNextInt())
				{
					int addNum = in.nextInt();
					Customer c = new Customer();
					List <Address> addList = new ArrayList<Address>();
					serobj.addAddress(addList,addNum,c);
					serobj.addCustomer(custArr, c, acctno, passwd, balance,addList);
				}
				else
				{
					System.out.println("Enter Correct number of Address");
				}
				//balVer = false;
			}
			else
			{
				System.out.println("Enter Correct balance");
			}
			}
			
			break;
		case 2:
			System.out.println(custArr);
			//code to display customers
			break;
		case 3:
			//Code for Login
			System.out.println("Enter the Account number");
			String acctno1 = in.next();
			System.out.println("Enter the Password");
			String pass1 = in.next();
			for(Customer c1: custArr)
			{
				if(c1.getAccNo().equals(acctno1) && c1.getPassword().equals(pass1))
				{
					boolean innerSwitch = true;
					
					while(innerSwitch)
					{
					System.out.println("Enter \n 1 for Check balance \n 2 for Deposit \n 3 for Withdraw \n 4 for Transfer \n 5 for logout");
					int option = in.nextInt();
					switch(option)
					{ 
						case 1 :
							System.out.println(c1);
							break;
						case 2:
							System.out.println("Enter the amount to be deposited");
							double amountDep = in.nextDouble();
							System.out.println(serobj.deposit(c1 , amountDep));
							
							break;
						case 3:
							System.out.println("enter the amount to withdraw");
							double amountWith = in.nextDouble();
							System.out.println(serobj.withDraw(c1 , amountWith));
							break;
							
						case 4:
							int OTP = serobj.generateOTP();
							System.out.println(OTP);
							System.out.println("ENter the OTP");
							int OTPEnt=in.nextInt();
							if(OTPEnt==OTP)
							{
							System.out.println("enter the amount to transfer");
							double amountTra = in.nextDouble();
							System.out.println(serobj.transfer(c1,amountTra));
							}
							else
							{
								System.out.println("OTP entered incorrectly");
							}
							
							break;
							
						case 5:
							innerSwitch =false;
							//System.exit(1);
						break;
							
						default:
							System.out.println("Invalid option");
						}
					
					}
				}
			}
			
			
			//code for services
			break;
		case 4:
			System.exit(1);
			break;
		default:
			System.out.println("Enter correct option");
			break;
				
		}
		}
		else
		{
			System.out.println("Enter valid number");
		}
		
		//in.close();
		}
		
	
	}
}
		
