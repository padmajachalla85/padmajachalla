package com.hcl.day5assign;

import java.util.Scanner;
public class SwapNumbers
{

	public static void main(String args[])
	{
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the numbers");
		int x = in.nextInt();
		int y = in.nextInt();
		
		x = x + y;
		y = x - y;
		x = x - y;
		
		System.out.println("After Swapping");
		System.out.println(x);
		System.out.println(y);
		
		
	
		
	}
}
