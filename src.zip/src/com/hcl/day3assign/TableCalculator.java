package com.hcl.day3assign;
import java.util.Scanner;
public class TableCalculator
{

	static void printTable(int i)
	{
		for(int j=1;j<=10;j++)
		{
			System.out.println(i*j);
		}
	}


public static void main(String args[])
{
boolean wantToContinue=true;
	
	while(wantToContinue)
	{
	Scanner in = new Scanner(System.in);
	System.out.println("Enter the number");
	int n = in.nextInt();
	printTable(n);
	System.out.println("Want To exit? press Y for yes");
	if(in.next().equals("Y"))
	{
		wantToContinue=false;
	}
		
		
	}	
	}
}