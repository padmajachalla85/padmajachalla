package training;

public class Test {
	
	public static void main (String args[]) {
		System.out.println("Calling Method Name");
		name();
	}

	private static void name() {
		String a = "Padmaja";
		String b = "Challa";
		String c = a.concat(b);
		System.out.println("Testing Name " + c);
	}

}
