package training;
import java.util.Scanner;
public class CheckLeapYear 
{
	public static void main(String args[])
	{
		System.out.println("Enter the year");
		Scanner in = new Scanner(System.in);
		int year = in.nextInt();
		String s=checkLeapYear(year);
		System.out.println("The year entered is " +s);
	}
	
	public static String checkLeapYear(int a)
	{
		if((a%400 == 0) || ((a%4 == 0) && (a%100 != 0)) )
		{
			return "a Leap Year";
		}
		else 
			return "not a Leap Year";
	}

}
