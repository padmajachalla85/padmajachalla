package com.hcl.day4assign;

class Employee implements ICommon
{

	@Override
	public String markAttendance() {
		// TODO Auto-generated method stub
		return "Attendance marked for today";
	}

	@Override
	public String dailyTask() {
		// TODO Auto-generated method stub
		return "Complete coding of module 1";
	}

	@Override
	public String displayDetails() {
		// TODO Auto-generated method stub
		return "Employee details";
	}
		
	
}

class Manager implements ICommon
{

	@Override
	public String markAttendance() {
		// TODO Auto-generated method stub
		return "Attendance marked for today";
	}

	@Override
	public String dailyTask() {
		// TODO Auto-generated method stub
		return "Create project architecture";
	}

	@Override
	public String displayDetails() {
		// TODO Auto-generated method stub
		return "Manager details";
	}
	
	
}


public class CommonImple 
{
	public static void main(String args[])
	{
		Employee emp = new Employee();
		System.out.println(	emp.displayDetails());
		System.out.println(emp.dailyTask());
		System.out.println(	emp.markAttendance());
		Manager manager = new Manager();
		System.out.println(	manager.displayDetails());
		System.out.println(manager.markAttendance());
		System.out.println(	manager.dailyTask());
		
	}

}
