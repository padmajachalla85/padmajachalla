package com.hcl.banking.beans;

public class Address
{
	private int houseNo;
	private String StreetName;
	private String cityName;
	private int pinCode;
	
	public int getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(int houseNo) {
		this.houseNo = houseNo;
	}
	public String getStreetName() {
		return StreetName;
	}
	public void setStreetName(String streetName) {
		StreetName = streetName;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	
	@Override
	public String toString() {
		return "Address [houseNo=" + houseNo + ", StreetName=" + StreetName + ", cityName=" + cityName + ", pinCode="
				+ pinCode + "]";
	}
	
	
	
	
}
