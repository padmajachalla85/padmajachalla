package training;
import java.util.*;
public class HelloWorld {
public static void main(String args[])
{
	
	
}
}