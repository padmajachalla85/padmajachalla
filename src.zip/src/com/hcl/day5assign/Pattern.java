package com.hcl.day5assign;
import java.util.Scanner;
public class Pattern
{
	public static void main(String args[])
	{
		System.out.println("Enter the number");
		Scanner in = new Scanner(System.in);
		int num = in.nextInt();	
		printPattern(num);
		
	}

	static void printPattern(int num)
	{
		int count = 1;
		for(int i=0;i<num;i++)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print(count+" ");
				count++;
				
			}
			System.out.println();
			
		}

	}
}
