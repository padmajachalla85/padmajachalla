package com.hcl.day5assign;
import java.util.Scanner;
public class Calculator
{
	public static void main(String args[])
	{
		while(true)
		{
		System.out.println("Enter 1 for ADDITION\n2 for SUBSTRACTION\n3 for MULTIPLICATION\n4 for DIVISION\n5 for EXIT");
		Scanner in = new Scanner(System.in);
		int option = in.nextInt();
		switch(option)
		{
		case 1:
			System.out.println("Enter the First Number:");
			int aa = in.nextInt();
			System.out.println("Enter the Second Number");
			int ab = in.nextInt();
			System.out.println("The Sum of numbers is :" +addition(aa,ab));
			break;
			
		case 2:
			System.out.println("Enter the First Number:");
			int sa = in.nextInt();
			System.out.println("Enter the Second Number");
			int sb = in.nextInt();
			System.out.println("The Difference of numbers is :" +substraction(sa,sb));
			break;
			
		case 3:
			System.out.println("Enter the First Number:");
			int ma = in.nextInt();
			System.out.println("Enter the Second Number");
			int mb = in.nextInt();
			System.out.println("The Sum of numbers is :" +multiplication(ma,mb));
			break;
		case 4:
			System.out.println("Enter the First Number:");
			int da = in.nextInt();
			System.out.println("Enter the Second Number");
			int db = in.nextInt();
			if (db != 0)
			System.out.println("The Sum of numbers is :" +division(da,db));
			else
			System.out.println("Cannot be divided");
			break;
		case 5:
			System.exit(1);
			break;
		default:
			System.out.println("Choose Correct Option");
		
			
		
		}
		}
	}

	
	
	private static int addition(int aa, int ab) {
		// TODO Auto-generated method stub
		
		return aa+ab;
		
	}

	private static int substraction(int sa, int sb) {
		// TODO Auto-generated method stub
		return sa-sb;
	}

	private static int multiplication(int ma, int mb) {
		// TODO Auto-generated method stub
		return ma*mb;
	}

	private static int division(int da, int db) {
		// TODO Auto-generated method stub
		return da/da;
		
	}


}
